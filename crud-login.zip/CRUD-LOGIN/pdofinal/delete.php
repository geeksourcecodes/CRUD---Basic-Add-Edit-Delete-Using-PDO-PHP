<?php
include('connect.php');

$edittable=$_POST['selector'];
$N = count($edittable);
for($i=0; $i < $N; $i++)
{
	$result = $db->prepare("DELETE FROM tb_user WHERE id= :memid");
	$result->bindParam(':memid', $edittable[$i]);
	$result->execute();
}
header("location: index.php");
mysql_close($con);
?>