<form action="delete.php" method="post">
<table border="1" cellspacing="0" cellpadding="2" >
<thead>
	<tr>
		<th> &nbsp; </th>
		<th> &nbsp; </th>
		<th> Username </th>
		<th> Name </th>
		<th> Gender </th>
		<th> Address </th>
		<th> Password </th>
	</tr>
</thead>
<tbody>
	<?php
		include('connect.php');
		$result = $db->prepare("SELECT * FROM tb_user ORDER BY id ASC");
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
	<tr class="record">
		<td><input name="selector[]" type="checkbox" value="<?php echo $row['id']; ?>"></td>
		<td><button type="submit" formaction="/pdofinal/editform.php?id=<?php echo $row['id']; ?>">edit</button></td>
		<td><?php echo $row['username']; ?></td>
		<td><?php echo $row['name']; ?></td>
		<td><?php echo $row['gender']; ?></td>
		<td><?php echo $row['address']; ?></td>
		<td><?php echo $row['password']; ?></td>
	<?php
		}
	?>
</tbody>
</table>
<button type="submit" formaction="/pdofinal/index_add.php">add</button>

<input type="submit" value="delete" />
</form>


